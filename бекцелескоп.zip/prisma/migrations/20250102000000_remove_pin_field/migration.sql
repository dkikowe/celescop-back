-- RemovePinField
ALTER TABLE "User" DROP COLUMN "pin";
